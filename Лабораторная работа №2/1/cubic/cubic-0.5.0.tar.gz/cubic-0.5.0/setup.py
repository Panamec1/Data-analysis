from setuptools import setup

setup(
    name='cubic',
    version='0.5.0',    
    description='A example Python package',
    url='https://github.com/std',
    author='Ilia Beregovenko',
    author_email='noville@lostmail.com',
    license='BSD 2-clause',
    packages=['cubic']
)
